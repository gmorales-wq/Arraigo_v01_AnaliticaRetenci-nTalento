"""Tests de carga y validación de datos."""

from __future__ import annotations

import io

import pandas as pd
import pytest

import config as cfg
import data
from create_mock_data import generate_mock_data


def _valid_raw(n: int = 20) -> pd.DataFrame:
    """Devuelve un DataFrame ficticio válido, con todas las celdas como objeto."""
    return generate_mock_data(n=n, seed=3).astype(object)


def test_mock_data_passes_validation_without_issues() -> None:
    df, report = data.validate_dataframe(_valid_raw())
    assert not report.has_blocking_errors
    assert [i for i in report.issues if i.severity != "info"] == []
    assert len(df) == 20


def test_mock_data_has_no_sensitive_columns_by_default() -> None:
    df = generate_mock_data(n=30)
    assert cfg.COL_EDAD not in df.columns
    assert cfg.COL_GENERO not in df.columns


def test_mock_data_is_reproducible() -> None:
    pd.testing.assert_frame_equal(generate_mock_data(n=50, seed=9), generate_mock_data(n=50, seed=9))


def test_missing_required_column_is_blocking() -> None:
    raw = _valid_raw().drop(columns=[cfg.COL_CLIMA])
    _, report = data.validate_dataframe(raw)
    assert report.has_blocking_errors
    assert any(cfg.COL_CLIMA in i.column for i in report.issues if i.severity == "error")


def test_pii_columns_are_dropped() -> None:
    raw = _valid_raw()
    raw["Nombre"] = "Ana"
    raw["Email"] = "ana@example.com"
    raw["DNI"] = "12345678Z"
    df, report = data.validate_dataframe(raw)
    assert set(report.dropped_pii) == {"Nombre", "Email", "DNI"}
    assert not {"Nombre", "Email", "DNI"} & set(df.columns)


def test_short_pii_pattern_does_not_match_inside_words() -> None:
    raw = _valid_raw()
    raw["Ingeniero_Senior"] = "x"  # contiene "nie" pero no es un NIE
    _, report = data.validate_dataframe(raw)
    assert "Ingeniero_Senior" in report.dropped_unknown
    assert "Ingeniero_Senior" not in report.dropped_pii


def test_absence_cause_columns_are_rejected() -> None:
    raw = _valid_raw()
    raw["Causa_Ausencia"] = "gripe"
    raw["Diagnóstico"] = "x"
    df, report = data.validate_dataframe(raw)
    assert set(report.rejected_absence_cause) == {"Causa_Ausencia", "Diagnóstico"}
    assert "Causa_Ausencia" not in df.columns


def test_unknown_columns_are_dropped_for_minimisation() -> None:
    raw = _valid_raw()
    raw["Estado_Civil"] = "Soltero"
    df, report = data.validate_dataframe(raw)
    assert "Estado_Civil" in report.dropped_unknown
    assert "Estado_Civil" not in df.columns


def test_out_of_range_values_become_missing_with_warning() -> None:
    raw = _valid_raw()
    raw.loc[0, cfg.COL_CLIMA] = 9
    raw.loc[1, cfg.COL_COMPA] = "abc"
    df, report = data.validate_dataframe(raw)
    assert pd.isna(df.loc[0, cfg.COL_CLIMA])
    assert pd.isna(df.loc[1, cfg.COL_COMPA])
    clima_issue = next(i for i in report.issues if i.column == cfg.COL_CLIMA)
    assert clima_issue.severity == "warning"
    assert clima_issue.rows == [2]  # fila 0 de datos = fila 2 de la hoja
    assert not report.has_blocking_errors


def test_duplicate_ids_are_blocking() -> None:
    raw = _valid_raw()
    raw.loc[1, cfg.COL_ID] = raw.loc[0, cfg.COL_ID]
    _, report = data.validate_dataframe(raw)
    assert report.has_blocking_errors


@pytest.mark.parametrize("bad_id", ["ana@empresa.com", "12345678Z", "X1234567L"])
def test_ids_that_look_like_direct_identifiers_are_blocking(bad_id: str) -> None:
    raw = _valid_raw()
    raw.loc[0, cfg.COL_ID] = bad_id
    _, report = data.validate_dataframe(raw)
    assert report.has_blocking_errors


def test_category_normalisation_and_column_synonyms() -> None:
    raw = _valid_raw()
    raw.loc[0, cfg.COL_MODALIDAD] = "hibrido"
    raw.loc[1, cfg.COL_NIVEL] = "MANAGER"
    raw = raw.rename(columns={cfg.COL_EVAL_2025: "Evaluacion Desempeno 2025"})
    raw["Sexo"] = "Mujer"
    df, report = data.validate_dataframe(raw)
    assert df.loc[0, cfg.COL_MODALIDAD] == "Híbrido"
    assert df.loc[1, cfg.COL_NIVEL] == "Mánager"
    assert cfg.COL_EVAL_2025 in df.columns
    assert cfg.COL_GENERO in df.columns


def test_csv_with_semicolon_and_decimal_comma() -> None:
    raw = generate_mock_data(n=15, seed=4)
    content = raw.to_csv(index=False, sep=";", decimal=",").encode("utf-8")
    df, report = data.load_and_validate(content, "datos.csv", max_mb=5)
    assert df is not None, report.to_frame()
    assert df[cfg.COL_COMPA].dtype == "Float64"
    assert df[cfg.COL_COMPA].notna().all()


def test_xlsx_roundtrip() -> None:
    raw = generate_mock_data(n=15, seed=5)
    buffer = io.BytesIO()
    raw.to_excel(buffer, index=False)
    df, report = data.load_and_validate(buffer.getvalue(), "datos.xlsx", max_mb=5)
    assert df is not None, report.to_frame()
    assert len(df) == 15


def test_bool_parsing_of_outcome() -> None:
    raw = _valid_raw(10)
    raw.loc[:3, cfg.COL_BAJA] = ["Sí", "no", "1", "quizá"]
    df, report = data.validate_dataframe(raw)
    assert df[cfg.COL_BAJA].tolist()[:3] == [True, False, True]
    assert pd.isna(df[cfg.COL_BAJA].iloc[3])
    assert any(i.column == cfg.COL_BAJA and i.rows == [5] for i in report.issues)


def test_file_too_large_and_bad_format() -> None:
    _, report = data.load_and_validate(b"x" * (2 * 1024 * 1024), "datos.csv", max_mb=1)
    assert report.has_blocking_errors
    _, report = data.load_and_validate(b"hola", "datos.txt", max_mb=1)
    assert report.has_blocking_errors
    _, report = data.load_and_validate(b"not a zip", "datos.xlsx", max_mb=1)
    assert report.has_blocking_errors
