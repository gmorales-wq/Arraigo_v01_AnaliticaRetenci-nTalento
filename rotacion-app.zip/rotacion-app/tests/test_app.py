"""Prueba de humo de la interfaz con el ejecutor de tests de Streamlit."""

from __future__ import annotations

from pathlib import Path

from streamlit.testing.v1 import AppTest

APP_PATH = str(Path(__file__).resolve().parent.parent / "app.py")


def _run(at: AppTest) -> AppTest:
    at.run(timeout=60)
    assert not at.exception, [e.value for e in at.exception]
    assert not at.error, [e.value for e in at.error]
    return at


def test_app_runs_with_mock_data() -> None:
    at = _run(AppTest.from_file(APP_PATH, default_timeout=60))
    labels = [t.label for t in at.tabs]
    assert labels[0].endswith("Dashboard")
    assert "⚖️ Auditoría de equidad" not in labels  # sin columnas sensibles por defecto
    assert len(at.metric) >= 8
    assert "🤖 Modelo predictivo" in labels


def test_app_shows_fairness_tab_with_sensitive_mock_data() -> None:
    at = _run(AppTest.from_file(APP_PATH, default_timeout=60))
    at.checkbox(key="mock_sensitive").check()
    _run(at)
    assert "⚖️ Auditoría de equidad" in [t.label for t in at.tabs]


def test_filters_and_config_reset_do_not_break_the_app() -> None:
    at = _run(AppTest.from_file(APP_PATH, default_timeout=60))
    at.multiselect(key="filtro_Tramo_Riesgo").select("Alto")
    _run(at)
    at.button[-1].click()  # «Restaurar valores por defecto» (último botón de la página)
    _run(at)


def test_upload_mode_without_file_shows_schema() -> None:
    at = _run(AppTest.from_file(APP_PATH, default_timeout=60))
    at.radio(key="origen").set_value("Archivo propio (CSV o XLSX)")
    _run(at)
    assert any("Carga un archivo" in i.value for i in at.info)
