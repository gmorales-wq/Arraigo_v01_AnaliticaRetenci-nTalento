"""Tests del modelo predictivo (regresión logística)."""

from __future__ import annotations

import pandas as pd
import pytest

import config as cfg
import data
import fairness as fa
import model as ml
import scoring

KEYS = [f.key for f in cfg.FACTORS if cfg.ScoringConfig().weights[f.key] > 0]


@pytest.fixture(scope="module")
def scored() -> pd.DataFrame:
    df = data.prepare_mock(500, 42, include_sensitive=True)
    return scoring.score_dataframe(df, cfg.ScoringConfig())


def test_model_trains_on_mock_history(scored: pd.DataFrame) -> None:
    result = ml.train_model(scored, KEYS)
    assert result.trained
    assert 0.5 < result.auc_model_cv <= 1.0
    proba = result.predictions[ml.COL_PROBA]
    assert proba.between(0, 1).all()
    assert len(proba) == len(scored)


def test_model_never_uses_sensitive_attributes(scored: pd.DataFrame) -> None:
    result = ml.train_model(scored, KEYS)
    assert set(result.coefficients.index) == set(KEYS)
    altered = scored.copy()
    altered[cfg.COL_EDAD] = 99
    altered[cfg.COL_GENERO] = "Otro"
    other = ml.train_model(altered, KEYS)
    pd.testing.assert_series_equal(result.predictions[ml.COL_PROBA], other.predictions[ml.COL_PROBA])


def test_model_learns_expected_direction_for_salary(scored: pd.DataFrame) -> None:
    # En los datos ficticios, un compa-ratio bajo aumenta la probabilidad de baja.
    result = ml.train_model(scored, KEYS)
    assert result.coefficients["compa_ratio"] < 0


def test_logit_contributions_reproduce_probability(scored: pd.DataFrame) -> None:
    import numpy as np

    result = ml.train_model(scored, KEYS)
    preds = result.predictions
    logit_cols = [c for c in preds.columns if c.startswith(ml.LOGIT_PREFIX)]
    # logit = intercepto + suma de aportes -> el intercepto debe ser constante para todas las filas
    implied_intercept = np.log(preds[ml.COL_PROBA] / (1 - preds[ml.COL_PROBA])) - preds[logit_cols].sum(axis=1)
    assert implied_intercept.std() < 1e-6


def test_unlabeled_rows_are_scored_but_not_used_for_training(scored: pd.DataFrame) -> None:
    partial = scored.copy()
    partial.loc[partial.index[-50:], cfg.COL_BAJA] = pd.NA
    result = ml.train_model(partial, KEYS)
    assert result.trained
    assert result.n_train == len(scored) - 50
    assert result.n_scored_unlabeled == 50
    assert partial.index[-50:].isin(result.predictions[ml.COL_PROBA].dropna().index).all()


def test_insufficient_history_is_reported(scored: pd.DataFrame) -> None:
    few = scored.head(60)
    result = ml.train_model(few, KEYS)
    assert not result.trained
    assert "insuficiente" in result.message
    assert not ml.train_model(scored.drop(columns=[cfg.COL_BAJA]), KEYS).trained
    assert not ml.train_model(scored, KEYS[:1]).trained


def test_probability_by_group_suppresses_small_groups(scored: pd.DataFrame) -> None:
    result = ml.train_model(scored, KEYS)
    with_proba = scored.join(result.predictions)
    table = fa.probability_by_group(with_proba, cfg.COL_GENERO, 10_000, ml.COL_PROBA)
    assert (table["Probabilidad media (%)"] == fa.SUPPRESSED_TEXT).all()
