"""Tests del motor de scoring, el plan de acción y la auditoría de equidad."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

import config as cfg
import data
import fairness as fa
import recommendations as rec
import scoring


@pytest.fixture(scope="module")
def mock_df() -> pd.DataFrame:
    return data.prepare_mock(400, 11, include_sensitive=True)


@pytest.fixture(scope="module")
def scored(mock_df: pd.DataFrame) -> pd.DataFrame:
    return scoring.score_dataframe(mock_df, cfg.ScoringConfig())


# ------------------------------------------------------------------ rampas
@pytest.mark.parametrize(
    ("value", "zero_at", "max_at", "expected"),
    [
        (1.0, 1.0, 0.8, 0.0),   # en el umbral sin riesgo
        (0.8, 1.0, 0.8, 1.0),   # en el umbral máximo
        (0.9, 1.0, 0.8, 0.5),   # punto medio, rampa descendente
        (0.5, 1.0, 0.8, 1.0),   # más allá del máximo: se recorta
        (1.2, 1.0, 0.8, 0.0),   # por encima del umbral sin riesgo: se recorta
        (42.0, 24, 60, 0.5),    # rampa ascendente
    ],
)
def test_ramp_intensity_edges(value: float, zero_at: float, max_at: float, expected: float) -> None:
    result = scoring.ramp_intensity(pd.Series([value]), zero_at, max_at).iloc[0]
    assert result == pytest.approx(expected)


def test_ramp_keeps_missing_as_missing() -> None:
    assert np.isnan(scoring.ramp_intensity(pd.Series([np.nan]), 0, 1).iloc[0])


def test_ramp_rejects_equal_thresholds() -> None:
    with pytest.raises(scoring.ScoringConfigError):
        scoring.ramp_intensity(pd.Series([1.0]), 2, 2)


# ------------------------------------------------------------------ score
def test_score_bounds_and_tiers(scored: pd.DataFrame) -> None:
    score = scored[scoring.COL_SCORE]
    assert score.between(0, 100).all()
    assert set(scored[scoring.COL_TRAMO].dropna()) <= set(cfg.TRAMOS)


def test_contributions_sum_to_score(scored: pd.DataFrame) -> None:
    contrib = scored[[c for c in scored.columns if c.startswith(scoring.CONTRIB_PREFIX)]].sum(axis=1)
    # El score se redondea a 1 decimal; las contribuciones no.
    assert (contrib - scored[scoring.COL_SCORE]).abs().max() <= 0.05 + 1e-9


def test_edad_and_genero_do_not_affect_score(mock_df: pd.DataFrame) -> None:
    config = cfg.ScoringConfig()
    base = scoring.score_dataframe(mock_df, config)[scoring.COL_SCORE]
    altered = mock_df.copy()
    altered[cfg.COL_EDAD] = 99
    altered[cfg.COL_GENERO] = "Otro"
    pd.testing.assert_series_equal(base, scoring.score_dataframe(altered, config)[scoring.COL_SCORE])


def test_missing_values_renormalise_weights() -> None:
    df = data.prepare_mock(20, 2, False)
    config = cfg.ScoringConfig()
    full = scoring.score_dataframe(df, config)
    df_missing = df.copy()
    df_missing.loc[0, cfg.COL_CLIMA] = pd.NA
    partial = scoring.score_dataframe(df_missing, config)
    active = sum(1 for w in config.weights.values() if w > 0)
    assert partial.loc[0, scoring.COL_FACTORES_DISP] == f"{active - 1}/{active}"
    assert full.loc[0, scoring.COL_FACTORES_DISP] == f"{active}/{active}"
    assert 0 <= partial.loc[0, scoring.COL_SCORE] <= 100


def test_all_factors_missing_gives_no_score() -> None:
    df = data.prepare_mock(10, 2, False)
    numeric = [s.name for s in cfg.SCHEMA if s.kind in ("int", "float") and s.name not in cfg.SENSITIVE_COLUMNS]
    df.loc[0, numeric] = pd.NA
    out = scoring.score_dataframe(df, cfg.ScoringConfig())
    assert pd.isna(out.loc[0, scoring.COL_SCORE])
    assert pd.isna(out.loc[0, scoring.COL_TRAMO])
    assert rec.priority_level(out.loc[0, scoring.COL_TRAMO], False) == 5


def test_worst_case_person_scores_100() -> None:
    df = data.prepare_mock(10, 2, False)
    worst = {
        cfg.COL_COMPA: 0.7, cfg.COL_CLIMA: 1.0, cfg.COL_MESES_PROMO: 100, cfg.COL_EVAL_2025: 1.0,
        cfg.COL_EVAL_2024: 4.0, cfg.COL_HORAS_EXTRA: 50.0, cfg.COL_ANTIGUEDAD: 12,
        cfg.COL_CAMBIOS_RESP: 4, cfg.COL_FORMACION: 0, cfg.COL_AUSENCIAS: 30,
    }
    for column, value in worst.items():
        df.loc[0, column] = value
    out = scoring.score_dataframe(df, cfg.ScoringConfig())
    assert out.loc[0, scoring.COL_SCORE] == pytest.approx(100.0)
    assert out.loc[0, scoring.COL_TRAMO] == "Alto"


def test_tier_boundaries() -> None:
    tiers = scoring.assign_tier(pd.Series([0.0, 24.9, 25.0, 34.9, 35.0, 100.0, np.nan]), 25, 35)
    assert tiers.tolist()[:6] == ["Bajo", "Bajo", "Medio", "Medio", "Alto", "Alto"]
    assert pd.isna(tiers.iloc[6])


@pytest.mark.parametrize(
    "mutate",
    [
        lambda c: c.weights.update({k: 0.0 for k in c.weights}),
        lambda c: c.weights.update({"clima": -1.0}),
        lambda c: c.max_at.update({"clima": c.zero_at["clima"]}),
        lambda c: setattr(c, "umbral_medio", 80.0),
    ],
)
def test_invalid_config_is_rejected(mutate) -> None:
    config = cfg.ScoringConfig()
    mutate(config)
    with pytest.raises(scoring.ScoringConfigError):
        scoring.validate_config(config)


def test_disabled_factor_contributes_zero(scored: pd.DataFrame) -> None:
    assert cfg.ScoringConfig().weights["ausencias"] == 0
    assert (scored[f"{scoring.CONTRIB_PREFIX}ausencias"] == 0).all()


# ------------------------------------------------------------------ validación
def test_auc_perfect_inverse_and_ties() -> None:
    y = pd.Series([False, False, True, True])
    assert scoring.roc_auc(pd.Series([1, 2, 3, 4]), y) == pytest.approx(1.0)
    assert scoring.roc_auc(pd.Series([4, 3, 2, 1]), y) == pytest.approx(0.0)
    assert scoring.roc_auc(pd.Series([1, 1, 1, 1]), y) == pytest.approx(0.5)
    assert scoring.roc_auc(pd.Series([1, 2]), pd.Series([True, True])) is None


def test_evaluate_against_outcome(scored: pd.DataFrame) -> None:
    result = scoring.evaluate_against_outcome(scored)
    assert result is not None
    assert int(result.confusion.to_numpy().sum()) == result.n
    assert 0.0 <= result.auc <= 1.0


def test_evaluate_without_outcome_column(scored: pd.DataFrame) -> None:
    assert scoring.evaluate_against_outcome(scored.drop(columns=[cfg.COL_BAJA])) is None


# ------------------------------------------------------------------ plan
def test_dominant_factors_ordered_and_limited() -> None:
    row = pd.Series({f"{scoring.CONTRIB_PREFIX}{f.key}": 0.0 for f in cfg.FACTORS})
    row[f"{scoring.CONTRIB_PREFIX}clima"] = 20
    row[f"{scoring.CONTRIB_PREFIX}compa_ratio"] = 10
    row[f"{scoring.CONTRIB_PREFIX}sobrecarga"] = 6
    row[f"{scoring.CONTRIB_PREFIX}formacion_baja"] = 5
    row[f"{scoring.CONTRIB_PREFIX}estancamiento"] = 1  # por debajo del mínimo
    assert rec.dominant_factors(row) == ["clima", "compa_ratio", "sobrecarga"]


def test_every_factor_has_a_rule() -> None:
    assert set(rec.RULES) == {f.key for f in cfg.FACTORS}


def test_action_plan_is_prioritised(scored: pd.DataFrame) -> None:
    plan = rec.build_action_plan(scored)
    assert len(plan) == len(scored)
    assert plan["Prioridad"].is_monotonic_increasing
    p1 = plan[plan["Prioridad"] == 1]
    assert (p1[scoring.COL_TRAMO] == "Alto").all()
    assert (p1["Talento_Clave"] == "Sí").all()


def test_csv_injection_is_neutralised() -> None:
    df = pd.DataFrame({"a": ["=CMD()", "+1", "-2", "@x", "normal"], "b": [1, 2, 3, 4, 5]})
    safe = rec.sanitize_for_csv(df)
    assert safe["a"].tolist() == ["'=CMD()", "'+1", "'-2", "'@x", "normal"]
    assert safe["b"].tolist() == [1, 2, 3, 4, 5]


# ------------------------------------------------------------------ equidad
def test_small_groups_are_suppressed() -> None:
    counts = pd.Series({"A": 50, "B": 40, "C": 3})
    assert fa.suppressed_groups(counts, 10) == {"C", "B"}  # supresión complementaria
    counts = pd.Series({"A": 50, "B": 4, "C": 3})
    assert fa.suppressed_groups(counts, 10) == {"B", "C"}
    counts = pd.Series({"A": 50, "B": 40})
    assert fa.suppressed_groups(counts, 10) == set()


def test_fairness_table_hides_figures_of_suppressed_groups(scored: pd.DataFrame) -> None:
    table = fa.fairness_table(scored, cfg.COL_GENERO, k=10_000)
    assert table["Suprimido"].all()
    assert (table["Score medio"] == fa.SUPPRESSED_TEXT).all()


def test_age_is_reported_only_in_bands(scored: pd.DataFrame) -> None:
    table = fa.fairness_table(scored, cfg.COL_EDAD, k=5)
    assert set(table["Grupo"]) <= {"Menos de 30", "30–44", "45–54", "55 o más", fa.SIN_DATO}


def test_proxy_analysis_flags_tenure_for_age(scored: pd.DataFrame) -> None:
    keys = [f.key for f in cfg.FACTORS if cfg.ScoringConfig().weights[f.key] > 0]
    proxy = fa.proxy_analysis(scored, cfg.COL_EDAD, 10, keys)
    # En los datos ficticios la edad se generó correlacionada con la antigüedad.
    assert proxy.iloc[0]["Factor"] == cfg.FACTORS_BY_KEY["antiguedad_temprana"].label
